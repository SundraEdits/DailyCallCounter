# Daily Call Report (native Android: Kotlin + Jetpack Compose + Room)

Six fixed locations, one-tap +1 / -1, live total, per-date records, WhatsApp share.

## Get the APK (no Android Studio needed)
1. Create a GitHub repository and upload the **contents** of this folder (keep the `.github` folder at the repo root).
2. Open the **Actions** tab, choose **Build APK** (runs on every push, or click **Run workflow**).
3. When the run is green, open it and download **DailyCallReport-APK** under *Artifacts*. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").

## Open in Android Studio
Open this folder. Or run `gradle wrapper --gradle-version 8.7` once, then `./gradlew assembleDebug`.

## Notes
- Data is stored in a local Room (SQLite) database, one row per date + location; every change is saved immediately.
- Counts cannot go below zero (enforced in the SQL update itself).
- Backup/restore is not included.
- The code was written without being compiled or run; the first GitHub build is the first real build.
