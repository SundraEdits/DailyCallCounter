package com.dailycallreport.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

val LOCATIONS = listOf("Muzaffarpur", "Patna", "Bhagalpur", "Ranchi", "Enquiry", "Lucknow")

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val date = MutableStateFlow(LocalDate.now())
    val error = MutableStateFlow<String?>(null)

    val counts: StateFlow<Map<String, Int>> = date
        .flatMapLatest { d -> dao.observe(d.toString()) }
        .map { rows -> LOCATIONS.associateWith { l -> rows.firstOrNull { it.location == l }?.count ?: 0 } }
        .catch { error.value = "Could not read saved data" }
        .stateIn(viewModelScope, SharingStarted.Eagerly, LOCATIONS.associateWith { 0 })

    fun change(loc: String, delta: Int) = viewModelScope.launch {
        try { dao.change(date.value.toString(), loc, delta) }
        catch (e: Exception) { error.value = "Could not save. Please try again." }
    }
    fun setDate(d: LocalDate) { date.value = d }
}
