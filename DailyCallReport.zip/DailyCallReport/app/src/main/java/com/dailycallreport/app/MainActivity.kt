package com.dailycallreport.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = Color(0xFF7FB2FF), surface = Color(0xFF1B2230), background = Color(0xFF0F141C))
                else lightColorScheme(primary = Color(0xFF1F3A5F), surface = Color.White, background = Color(0xFFF3F5F9))
            ) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen() } }
        }
    }
}

private val fmt = DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy", Locale.ENGLISH)

fun buildReport(date: LocalDate, counts: Map<String, Int>): String {
    val lines = LOCATIONS.joinToString("\n") { "$it: ${counts[it] ?: 0}" }
    val total = LOCATIONS.sumOf { counts[it] ?: 0 }
    val bar = "━━━━━━━━━━━━━━━━━━"
    return "📊 DAILY CALL REPORT\n📅 ${date.format(fmt)}\n\n$lines\n\n$bar\n📞 TOTAL CALLS: $total\n$bar\n\nDaily calling report submitted."
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(vm: MainViewModel = viewModel()) {
    val date by vm.date.collectAsState()
    val counts by vm.counts.collectAsState()
    val error by vm.error.collectAsState()
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var picker by remember { mutableStateOf(false) }
    val total = counts.values.sum()

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Daily Call Report", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.setDate(date.minusDays(1)) }) { Text("‹", fontSize = 24.sp) }
            OutlinedButton(onClick = { picker = true }, modifier = Modifier.weight(1f)) { Text("📅  ${date.format(fmt)}") }
            TextButton(onClick = { vm.setDate(date.plusDays(1)) }) { Text("›", fontSize = 24.sp) }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }

        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            LOCATIONS.chunked(2).forEach { pair ->
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { loc ->
                        CounterCard(loc, counts[loc] ?: 0, Modifier.weight(1f).fillMaxHeight(),
                            onMinus = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.change(loc, -1) },
                            onPlus = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); vm.change(loc, 1) })
                    }
                }
            }
        }

        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TOTAL CALLS", Modifier.weight(1f), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                AnimatedContent(total, transitionSpec = { (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut()) }, label = "total") {
                    Text("$it", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
        Button(
            onClick = {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, buildReport(date, counts)) }
                ctx.startActivity(Intent.createChooser(send, "Share report"))
            },
            modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1FA855), contentColor = Color.White)
        ) { Text("SHARE REPORT ON WHATSAPP", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp) }
    }

    if (picker) {
        val st = rememberDatePickerState(initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(onDismissRequest = { picker = false },
            confirmButton = { TextButton(onClick = {
                st.selectedDateMillis?.let { vm.setDate(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                picker = false
            }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { picker = false }) { Text("Cancel") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
fun CounterCard(name: String, count: Int, modifier: Modifier, onMinus: () -> Unit, onPlus: () -> Unit) {
    Card(modifier, shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedContent(count, transitionSpec = { (slideInVertically { it / 2 } + fadeIn()) togetherWith (slideOutVertically { -it / 2 } + fadeOut()) }, label = "c") {
                    Text("$it", fontSize = 44.sp, fontWeight = FontWeight.Bold)
                }
                Text("CALLS", fontSize = 11.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onMinus, enabled = count > 0, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(0.dp)) { Text("−1", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                Button(onClick = onPlus, modifier = Modifier.weight(1f).height(48.dp), contentPadding = PaddingValues(0.dp)) { Text("+1", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
