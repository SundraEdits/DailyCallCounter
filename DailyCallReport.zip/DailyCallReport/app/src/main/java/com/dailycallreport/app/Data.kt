package com.dailycallreport.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "call_counts", primaryKeys = ["date", "location"])
data class CallCount(val date: String, val location: String, val count: Int)

@Dao
abstract class CallDao {
    @Query("SELECT * FROM call_counts WHERE date = :date")
    abstract fun observe(date: String): Flow<List<CallCount>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun ensure(row: CallCount)

    // Guard in SQL: count can never drop below zero.
    @Query("UPDATE call_counts SET count = count + :delta WHERE date = :date AND location = :loc AND count + :delta >= 0")
    abstract suspend fun apply(date: String, loc: String, delta: Int)

    @Transaction
    open suspend fun change(date: String, loc: String, delta: Int) {
        ensure(CallCount(date, loc, 0))
        apply(date, loc, delta)
    }
}

@Database(entities = [CallCount::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): CallDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "calls.db").build().also { inst = it }
        }
    }
}
